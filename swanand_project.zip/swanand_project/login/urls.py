from django.contrib import admin
from django.urls import path,include
from django.urls import re_path
from .views import *

urlpatterns = [
    re_path(r'add-user/',add_user),
    re_path(r'get-user/',get_user),
    re_path(r'update-user/',update_user),
    re_path(r'delete-user/',deleteuser),
    re_path(r'login_page/',login)
]
