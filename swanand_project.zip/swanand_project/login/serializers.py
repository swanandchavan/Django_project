from rest_framework import serializers
from .models import Employees, Emp_login

class EmployeesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Employees
        fields = ('emp_id', 'first_name', 'last_name', 'phone', 'email_id', 'address', 'created_at', 'updated_at')

class Emp_loginSerializer(serializers.ModelSerializer):
    class Meta:
        model = Emp_login
        fields = ('emp_login_id', 'emp_id', 'last_login', 'passwd')

