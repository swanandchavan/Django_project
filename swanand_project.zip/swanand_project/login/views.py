from django.shortcuts import render
from rest_framework.decorators import api_view
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
import os
import datetime
from .models import Emp_login , Employees
from .serializers import Emp_loginSerializer, EmployeesSerializer

@api_view(['POST'])
def add_user(request , **kwargs):
    data = JSONParser().parse(request)
    emp_dict = {
        'first_name' : data['first_name'],
        'last_name' : data['last_name'],
        'phone' : data['phone'],
        'email_id': data['email_id'],
        'address' : data['address']
    }
    
    employeesSerializer = EmployeesSerializer(data = emp_dict)
    if employeesSerializer.is_valid():
        employeesSerializer.save()
        
        login_dict = {
            'passwd': data['passwd'],
            'emp_id': employeesSerializer.data['emp_id'],
        }
        
        emp_loginSerializer  = Emp_loginSerializer(data = login_dict)
        if emp_loginSerializer.is_valid():
            emp_loginSerializer.save()

            return JsonResponse({
                'message' : 'inserted in both table',
                'response': employeesSerializer.data,
                'status': 201
            })
        else :
            return JsonResponse({
            'message': 'emp in emp_table',
            'response': employeesSerializer.data,
            'status': 200
            })
    
    else :
            return JsonResponse({
            'message': 'failed to create',
            'response': [],
            'status': 500
            })

@api_view(['GET'])
def get_user(request, **kwargs):
    data = Employees.objects.all()
    emp_serializer = EmployeesSerializer(data, many =True)
    
    if emp_serializer :
        return JsonResponse({
            'message': 'employees data fetch',
            'response': emp_serializer.data,
            'status': 200
            })
    else :
            return JsonResponse({
            'message': 'failed to fetch',
            'response': emp_serializer.errors,
            'status': 500
            })
            
@api_view(['PATCH'])
def update_user(request, **kwargs):
    data = JSONParser().parse(request)
    check = Employees.objects.filter(emp_id = data['emp_id'])
    if check : 
        fetch_data = Employees.objects.get(emp_id = data['emp_id'])
        
        emp_Serializer = EmployeesSerializer(fetch_data,data = data, partial =True)
        if emp_Serializer.is_valid():
            emp_Serializer.save()
            
            return JsonResponse({
                'message': 'data update',
                'response': emp_Serializer.data,
                'status': 200
            })
            
        else:
            return JsonResponse
        ({
                'message':'data not updated',
                'response': emp_Serializer.errors,
                'status': 500
            })
    else :
        return JsonResponse({
            'message': 'data not found',
            'response':[],
            'status':404
        })

@api_view(['DELETE'])
def deleteuser(request, **kwargs):
    data = JSONParser().parse(request)
    check = Employees.objects.filter(emp_id = data['emp_id'])
    
    if check:
        check.delete()
        return JsonResponse({
            "message": "user delete",
            "respose": [],
            "status":200
        })
    else:
        return JsonResponse({
            "message": "data not deleted",
            "response": [],
            "status": 500
        })
        
        
@api_view(['POST'])
def login(request, **kwargs):
    data = JSONParser().parse(request)
    emailid = data["email_id"]
    paswd = data["passwd"]
    record_emp = Employees.objects.filter(email_id=data["email_id"])
    passwd_emp = Emp_login.objects.filter(passwd = data["passwd"])
    
    if record_emp and passwd_emp :
        return JsonResponse({
            "message": "Sucessfully Login",
            "respose": [],
            "status":200
        })
    else:
        return JsonResponse({
            "message": "Login Failed",
            "response": [],
            "status": 500
        })
    
    
    

# def deleteCourseAndCW(request, **kwargs):
#     data = JSONParser().parse(request)
#     course_id = data['course_id']
#     user_id = data['user_id']
#     record = CourseWriter.objects.filter(course_id=course_id, user_id=user_id)
#     if len(record) > 0 :
#         record.delete()
#         return JsonResponse({"message": "success", "status": 200, "response": []})
#     else:
#         return JsonResponse({"message": "Record doesn\'t exist.", "status": 404, "response": []})


# email id tya table madhun kadhun match kar
# passwd tya table madhun kadhun match kar
    